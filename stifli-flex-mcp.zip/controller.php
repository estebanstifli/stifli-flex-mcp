<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
class StifliFlexMcpController {
	// Puedes extender de una clase base si lo necesitas
}
